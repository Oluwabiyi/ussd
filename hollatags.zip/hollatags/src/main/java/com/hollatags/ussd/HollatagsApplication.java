package com.hollatags.ussd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HollatagsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HollatagsApplication.class, args);
	}

}

